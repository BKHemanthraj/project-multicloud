function alertOrder() {
    alert("Your order has been placed!");
}


